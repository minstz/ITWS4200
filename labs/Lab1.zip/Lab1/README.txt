README.txt


Resources used:
	jQuery
	Zerb Foundation
	Google Fonts

Animation effects were created just with jQuery slideUp and slideDown functions.
Had to do a lot of fiddling with the order of the script in order to make it have the desired effect.
In my solution, javascript continues to run for as long as the page is open, with a few delays.  I realize this is not very great from an optimization standpoint, but I couldn't figure out any other way to do it besides downloading a plugin