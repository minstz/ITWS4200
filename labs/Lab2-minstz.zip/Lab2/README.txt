README

Lab 2 - Zachary Minster

Resources:
	Foundation
	Forecast.io API
	Flaticon.com
	Google Fonts

Location Name was not included in the Forecast.io API, and instead of using another API request to Google (more overhead) I just didnt include the users location.  Besides, you should know where you are anyway.  If not, you have bigger problems than the weather forecast.

Weather icons were hand picked and downloaded from flaticon and provided for the 10 different icons used by the API.